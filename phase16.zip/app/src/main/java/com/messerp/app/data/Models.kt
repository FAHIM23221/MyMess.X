package com.messerp.app.data

import org.json.JSONObject

enum class Role { MEMBER, ADMIN, MAIN_ADMIN }

data class Profile(
    val id: String,
    val phone: String,
    val fullName: String,
    val memberCode: String,
    val roomNo: String?,
    val seatNo: String?,
    val joinDate: String,
    val status: String,
    val role: Role,
    val isCurrentManager: Boolean,
    val avatarUrl: String?,
    val fatherName: String? = null,
    val fatherPhone: String? = null,
    val motherName: String? = null,
    val motherPhone: String? = null,
    val guardianWaived: Boolean = false,
    val mustChangePassword: Boolean = false
) {
    val isActive: Boolean get() = status == "ACTIVE"
}

internal fun JSONObject.strOrNull(key: String): String? = if (isNull(key)) null else getString(key)

fun parseProfile(o: JSONObject): Profile = Profile(
    id = o.getString("id"),
    phone = o.getString("phone"),
    fullName = o.getString("full_name"),
    memberCode = o.getString("member_code"),
    roomNo = o.strOrNull("room_no"),
    seatNo = o.strOrNull("seat_no"),
    joinDate = o.getString("join_date"),
    status = o.getString("status"),
    // Unknown values fall back to the least privileged role.
    role = runCatching { Role.valueOf(o.getString("role")) }.getOrDefault(Role.MEMBER),
    isCurrentManager = o.optBoolean("is_current_manager", false),
    avatarUrl = o.strOrNull("avatar_url"),
    fatherName = o.strOrNull("father_name"),
    fatherPhone = o.strOrNull("father_phone"),
    motherName = o.strOrNull("mother_name"),
    motherPhone = o.strOrNull("mother_phone"),
    guardianWaived = o.optBoolean("guardian_waived", false),
    mustChangePassword = o.optBoolean("must_change_password", false)
)
